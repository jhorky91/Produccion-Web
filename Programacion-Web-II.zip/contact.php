<?php
include('inc/header.php');

require_once './vendor/autoload.php';

if (isset($_POST['enviar'])) {
try {
    // Create the SMTP Transport
    $transport = (new Swift_SmtpTransport('smtp.gmail.com', 465,'ssl'))
        ->setUsername('contactomovieshop@gmail.com')
        ->setPassword('contacto123');
 
    // Create the Mailer using your created Transport
    $mailer = new Swift_Mailer($transport);
 
    // Create a message
    $message = new Swift_Message();
 
    // Set a "subject"
    $message->setSubject('Contactarse MovieShop');
 
    // Set the "From address"
    $message->setFrom([$_POST['email'] => $_POST['nombre']]);
 
    // Set the "To address" [Use setTo method for multiple recipients, argument should be array]
    $message->addTo('contactomovieshop@gmail.com');
 
    // Set the plain-text "Body"
    $message->setBody("Email: ".$_POST['email']."\nNombre: ".$_POST['nombre']."\nMensaje: ".$_POST['mensaje']);
 
    // Send the message
    $result = $mailer->send($message);
    redirect('contact.php');
} catch (Exception $e) {
  echo $e->getMessage();
} }
?>
<section class="block block-bb">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 mx-auto">

          <div class="iconchunk iconchunk-top iconchunk-accent-1 text-center">
            <div class="iconchunk-content">
              <p class="mb-1" style="color: black;">
                <h1>¿Quienes Somos?</h1><br>
				Somos estudiantes en la Escuela Da Vinci de la carrera de Analista en Sistemas
              </p>


		              	<ul>
		              		<li>Jhorky Escalante Quispe</li>
		              		<li>Gilberto Ariel Prieto</li>
		              		<li>Roberto Andrés Rocco</li>
		              		<li>Rodrigo Sebastian Tolaba</li>
		              	</ul>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-8 mx-auto py-5">
          <div id="google-map">
          	              <p class="mb-1" style="color: black;">
                <h1>Visitanos</h1><br>

          			<iframe style="width:100%; height:350px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d820.9965489892207!2d-58.396387782290056!3d-34.60451056844648!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccaea670d4e67%3A0x2198c954311ad6d9!2sDa%20Vinci!5e0!3m2!1ses!2sar!4v1600835578184!5m2!1ses!2sar"></iframe>

          </div>
        </div>
      </div>

      <div class="row d-flex justify-content-center pb-4">
        <div class="col-lg-4 col-sm-6">
          <div class="iconchunk iconchunk-left iconchunk-accent-1 mb-3 mb-sm-0">
            <div class="iconchunk-content">
              <i class="fab fa-whatsapp" style="font-size: 40px;"></i><br>
              (+54-11) 5032-0076
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="iconchunk iconchunk-left iconchunk-accent-1">
            <div class="iconchunk-content">
              <i class="fas fa-envelope" style="font-size: 40px;"></i><br>
              <a href="mailto:soporte@movie-shop.com">soporte@movie-shop.com</a>
            </div>
          </div>
        </div>
      </div>
    
  </section>

  <section class="block pb-3">
    <div class="container">
      <div class="block-heading mb-5">
        <h2 class="block-title">Contactanos</h2>
        
        <div class="d-flex justify-content-center"><h5 class="mb-3">Utilice este formulario para enviarnos un mensaje rápido.</h5></div>
      </div>

      <div class="row">
        <div class="col-md-6 mx-auto">
          <form action="#" method="POST">
            <div class="form-group">
			          	
              <input type="text" class="form-control form-control-lg"
                     id="example-input-name"
                     placeholder="Nombre" name="nombre">
            </div>

            <div class="form-group">
              <input type="email" class="form-control form-control-lg"
                     id="example-input-email"
                     placeholder="Email" name="email">
            </div>

            <div class="form-group">
              <textarea placeholder="Escrib tu mensaje..."
                        class="form-control"
                        id="example-textarea" name="mensaje" rows="7"></textarea>
            </div>

            <div class="text-right">
                <a href="#" class="btn btn-danger">
            	    <span>Reset</span>
                </a>
                <input class="btn btn-success" type="submit" name="enviar" value="Enviar">
            </div>

          </form>
        </div>
      </div>
    </div>

  </section>

<?php
include('inc/footer.php');
?> 